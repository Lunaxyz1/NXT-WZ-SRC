#pragma once

//MISC
#define SMOOTH 0.1.f //1~20
#define Max_Cheat_Distance 400.f


//XOR Keys
#define STRING_XOR_KEY 0x6F