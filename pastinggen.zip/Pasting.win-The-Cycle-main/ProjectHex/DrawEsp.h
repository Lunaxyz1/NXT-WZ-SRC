#include <iostream>
#include <string>
#include <stdio.h>
#include "vector.h"
#include "defs.h"

int Width = GetSystemMetrics(SM_CXSCREEN);
int Height = GetSystemMetrics(SM_CYSCREEN);
